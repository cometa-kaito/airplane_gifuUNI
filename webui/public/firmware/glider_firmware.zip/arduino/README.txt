Glider Firmware (arduino フォルダ一式 / WebSerial 公開版)
======================================================
含まれるもの (arduino/):
  glider_ESP32C3_ground/    地上機ブリッジ (PC USB <-> ESP-NOW)
  glider_ESP32C3_aircraft/  機体ブリッジ  (ESP-NOW <-> nRF52840 UART)
  glider_nRF52840/          フライトコントローラ (IMU + PID + サーボ)

※ secrets.h は配布に含めません（ESP-NOW の実鍵のため）。
  各 ESP32-C3 で secrets.example.h を secrets.h にコピーして使ってください。

セットアップ:
  1. Arduino IDE で 3 スケッチを各ボードへ書き込む。
  2. secrets.example.h を secrets.h にコピーし、PMK / LMK を
     地上機・機体で「同じ値」に書き換える (openssl rand -hex 16 等)。
  3. 各 ESP32-C3 を USB 接続し /mac で自分の MAC を確認。
  4. /setpeer AA:BB:CC:DD:EE:FF で相手の MAC を設定 (地上機<->機体の双方向)。
     ※ NVS 保存後に自動再起動。USB(WebSerial) は一旦切れるので再接続する。
  5. 地上機を PC に USB 接続し、Web UI の Connect Device で接続。

ローカルコマンド (ESP32-C3, USB シリアル経由):
  /mac /stat /help /setpeer <MAC> /unpair /channel <1-13>
